@echo off
title LabCore - yangilash
echo.
echo   LabCore o'rnatilgan tizimni yangilaydi.
echo   Bemor ma'lumotlari, fayllar va sozlamalar tegilmaydi.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server\deploy\windows\yangilash.ps1"
echo.
pause
